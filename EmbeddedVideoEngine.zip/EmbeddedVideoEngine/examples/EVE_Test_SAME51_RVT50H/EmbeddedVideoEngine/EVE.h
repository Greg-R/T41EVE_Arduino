/*
@file    EVE.h
@brief   Contains FT81x/BT81x/BT82x API definitions
@version 6.0
@date    2025-04-19
@author  Rudolph Riedel

@section LICENSE

MIT License

Copyright (c) 2016-2025 Rudolph Riedel

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software
is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

@section History

6.0
- adding EVE5 / BT82x

*/

#ifndef EVE_H
#define EVE_H

#include "EVE_target.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "EVE_config.h"
#include "EVE_commands.h"

/* definitions that are shared across EVE2/EVE3/EVE4/EVE5 */

/* diplay list commands, most need OR's arguments */
#define DL_DISPLAY              ((uint32_t) 0x00000000UL)
#define DL_BITMAP_SOURCE        ((uint32_t) 0x01000000UL)
#define DL_CLEAR_COLOR_RGB      ((uint32_t) 0x02000000UL)
#define DL_TAG                  ((uint32_t) 0x03000000UL)
#define DL_COLOR_RGB            ((uint32_t) 0x04000000UL)
#define DL_BITMAP_HANDLE        ((uint32_t) 0x05000000UL)
#define DL_CELL                 ((uint32_t) 0x06000000UL)
#define DL_BITMAP_LAYOUT        ((uint32_t) 0x07000000UL)
#define DL_BITMAP_SIZE          ((uint32_t) 0x08000000UL)
#define DL_ALPHA_FUNC           ((uint32_t) 0x09000000UL)
#define DL_STENCIL_FUNC         ((uint32_t) 0x0A000000UL)
#define DL_BLEND_FUNC           ((uint32_t) 0x0B000000UL)
#define DL_STENCIL_OP           ((uint32_t) 0x0C000000UL)
#define DL_POINT_SIZE           ((uint32_t) 0x0D000000UL)
#define DL_LINE_WIDTH           ((uint32_t) 0x0E000000UL)
#define DL_CLEAR_COLOR_A        ((uint32_t) 0x0F000000UL)
#define DL_COLOR_A              ((uint32_t) 0x10000000UL)
#define DL_CLEAR_STENCIL        ((uint32_t) 0x11000000UL)
#define DL_CLEAR_TAG            ((uint32_t) 0x12000000UL)
#define DL_STENCIL_MASK         ((uint32_t) 0x13000000UL)
#define DL_TAG_MASK             ((uint32_t) 0x14000000UL)
#define DL_BITMAP_TRANSFORM_A   ((uint32_t) 0x15000000UL)
#define DL_BITMAP_TRANSFORM_B   ((uint32_t) 0x16000000UL)
#define DL_BITMAP_TRANSFORM_C   ((uint32_t) 0x17000000UL)
#define DL_BITMAP_TRANSFORM_D   ((uint32_t) 0x18000000UL)
#define DL_BITMAP_TRANSFORM_E   ((uint32_t) 0x19000000UL)
#define DL_BITMAP_TRANSFORM_F   ((uint32_t) 0x1A000000UL)
#define DL_SCISSOR_XY           ((uint32_t) 0x1B000000UL)
#define DL_SCISSOR_SIZE         ((uint32_t) 0x1C000000UL)
#define DL_CALL                 ((uint32_t) 0x1D000000UL)
#define DL_JUMP                 ((uint32_t) 0x1E000000UL)
#define DL_BEGIN                ((uint32_t) 0x1F000000UL)
#define DL_COLOR_MASK           ((uint32_t) 0x20000000UL)
#define DL_END                  ((uint32_t) 0x21000000UL)
#define DL_SAVE_CONTEXT         ((uint32_t) 0x22000000UL)
#define DL_RESTORE_CONTEXT      ((uint32_t) 0x23000000UL)
#define DL_RETURN               ((uint32_t) 0x24000000UL)
#define DL_MACRO                ((uint32_t) 0x25000000UL)
#define DL_CLEAR                ((uint32_t) 0x26000000UL)
#define DL_VERTEX_FORMAT        ((uint32_t) 0x27000000UL)
#define DL_BITMAP_LAYOUT_H      ((uint32_t) 0x28000000UL)
#define DL_BITMAP_SIZE_H        ((uint32_t) 0x29000000UL)
#define DL_PALETTE_SOURCE       ((uint32_t) 0x2A000000UL)
#define DL_VERTEX_TRANSLATE_X   ((uint32_t) 0x2B000000UL)
#define DL_VERTEX_TRANSLATE_Y   ((uint32_t) 0x2C000000UL)
#define DL_NOP                  ((uint32_t) 0x2D000000UL)

#define DL_VERTEX2F             ((uint32_t) 0x40000000UL)
#define DL_VERTEX2II            ((uint32_t) 0x80000000UL)


/* Inline functions that work like the function-like macros from Bridgetek: */

/**
 * @brief Set the alpha test function.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t ALPHA_FUNC(const uint8_t func, const uint8_t ref)
{
    uint32_t const funcv = ((uint32_t) func & 7U) << 8U;
    return (DL_ALPHA_FUNC | funcv | ref);
}

/**
 * @brief Set the source bitmap memory format and layout for the current handle.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t BITMAP_LAYOUT(const uint8_t format, const uint16_t linestride, const uint16_t height)
{
    uint32_t const formatv = ((uint32_t) format & 0x1FUL) << 19U;
    uint32_t const linestridev = ((uint32_t) linestride & 0x3FFUL) << 9U;
    uint32_t const heightv = height & 0x1FFUL;
    return (DL_BITMAP_LAYOUT | formatv | linestridev | heightv);
}

/**
 * @brief Set the 2 most significant bits of the source bitmap memory format and layout for the current handle.
 * @param linestride 12-bit value specified to BITMAP_LAYOUT
 * @param height 11-bit value specified to BITMAP_LAYOUT
 * @note this is different to FTDIs implementation as this takes the original values as parameters and not only the upper bits
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t BITMAP_LAYOUT_H(const uint16_t linestride, const uint16_t height)
{
    uint32_t const linestridev = (uint32_t) ((((linestride & 0xC00U) >> 10U) &3UL) << 2U);
    uint32_t const heightv = (uint32_t) (((height & 0x600U) >> 9U) & 3UL);
    return (DL_BITMAP_LAYOUT_H | linestridev | heightv);
}

/**
 * @brief Set the source bitmap memory format and layout for the current handle.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t BITMAP_SIZE(const uint8_t filter, const uint8_t wrapx, const uint8_t wrapy, const uint16_t width, const uint16_t height)
{
    uint32_t const filterv = (filter & 0x1UL) << 20U;
    uint32_t const wrapxv = (wrapx & 0x1UL) << 19U;
    uint32_t const wrapyv = (wrapy & 0x1UL) << 18U;
    uint32_t const widthv = (width & 0x1FFUL) << 9U;
    uint32_t const heightv = height & 0x1FFUL;
    return (DL_BITMAP_SIZE | filterv | wrapxv | wrapyv | widthv | heightv);
}

/**
 * @brief Set the 2 most significant bits of bitmaps dimension for the current handle.
 * @param linestride 11-bit value of bitmap width, the 2 most significant bits are used
 * @param height 11-bit value of bitmap width, the 2 most significant bits are used
 * @note this is different to FTDIs implementation as this takes the original values as parameters and not only the upper bits
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t BITMAP_SIZE_H(const uint16_t width, const uint16_t height)
{
    uint32_t const widthv = (uint32_t) ((((width & 0x600U) >> 9U) & 3UL) << 2U);
    uint32_t const heightv = (uint32_t) (((height & 0x600U) >> 9U) & 3UL);
    return ((DL_BITMAP_SIZE_H) | widthv | heightv);
}

/**
 * @brief Set the source address of bitmap data in RAM_G or flash memory.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t BITMAP_SOURCE(const uint32_t addr)
{
    return (DL_BITMAP_SOURCE | (addr & 0x3FFFFFUL));
}

/**
 * @brief Set the C coefficient of the bitmap transform matrix.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t BITMAP_TRANSFORM_C(const uint32_t val)
{
    return (DL_BITMAP_TRANSFORM_C | (val & 0x1FFFFUL));
}

/**
 * @brief Set the F coefficient of the bitmap transform matrix.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t BITMAP_TRANSFORM_F(const uint32_t val)
{
    return (DL_BITMAP_TRANSFORM_F | (val & 0x1FFFFUL));
}

/**
 * @brief Specify how new color values are combined with the values already in the color buffer.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t BLEND_FUNC(const uint8_t src, const uint8_t dst)
{
    uint32_t const srcv = (uint32_t) ((src & 7UL) << 3U);
    uint32_t const dstv = (uint32_t) (dst & 7UL);
    return (DL_BLEND_FUNC | srcv | dstv);
}

/**
 * @brief Set the bitmap cell number for the VERTEX2F command.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t CELL(const uint8_t cell)
{
    return (DL_CELL | (cell & 0x7FUL));
}

/**
 * @brief Clear buffers to preset values.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t CLEAR(const uint8_t color, const uint8_t stencil, const uint8_t tag)
{
    uint32_t const colorv = (color & 1UL) << 2U;
    uint32_t const stencilv = (stencil & 1UL) << 1U;
    uint32_t const tagv = (tag & 1UL);
    return (DL_CLEAR | colorv | stencilv | tagv);
}

/**
 * @brief Set clear value for the alpha channel.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t CLEAR_COLOR_A(const uint8_t alpha)
{
    return (DL_CLEAR_COLOR_A | alpha);
}

/**
 * @brief Set clear values for red, green and blue channels.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t CLEAR_COLOR_RGB(const uint8_t red, const uint8_t green, const uint8_t blue)
{
    uint32_t const redv = ((red & 0xFFUL) << 16U);
    uint32_t const greenv = ((green & 0xFFUL) << 8U);
    uint32_t const bluev = (blue & 0xFFUL);
    return (DL_CLEAR_COLOR_RGB | redv | greenv | bluev);
}

/**
 * @brief Set clear value for the stencil buffer.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t CLEAR_STENCIL(const uint8_t val)
{
    return (DL_CLEAR_STENCIL | val);
}

/**
 * @brief Set the current color alpha.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t COLOR_A(const uint8_t alpha)
{
    return (DL_COLOR_A | alpha);
}

/**
 * @brief Enable or disable writing of color components.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t COLOR_MASK(const uint8_t red, const uint8_t green, const uint8_t blue, const uint8_t alpha)
{
    uint32_t const redv = ((red & 1UL) << 3U);
    uint32_t const greenv = ((green & 1UL) << 2U);
    uint32_t const bluev = ((blue & 1UL) << 1U);
    uint32_t const alphav = (alpha & 1UL);
    return (DL_COLOR_MASK | redv | greenv | bluev | alphav);
}

/**
 * @brief Set the current color red, green and blue.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t COLOR_RGB(const uint8_t red, const uint8_t green, const uint8_t blue)
{
    uint32_t const redv = ((red & 0xFFUL) << 16U);
    uint32_t const greenv = ((green & 0xFFUL) << 8U);
    uint32_t const bluev = (blue & 0xFFUL);
    return (DL_COLOR_RGB | redv | greenv | bluev);
}

/**
 * @brief Set the width of lines to be drawn with primitive LINES in 1/16 pixel precision.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t LINE_WIDTH(const uint16_t width)
{
    return (DL_LINE_WIDTH | (width & 0xFFFUL));
}

/**
 * @brief Execute a single command from a macro register.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t MACRO(const uint8_t macro)
{
    return (DL_MACRO | (macro & 0x1UL));
}

/**
 * @brief Set the radius of points to be drawn with primitive POINTS in 1/16 pixel precision.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t POINT_SIZE(const uint16_t size)
{
    return (DL_POINT_SIZE | (size & 0x1FFFUL));
}

/**
 * @brief Set the size of the scissor clip rectangle.
 * @note valid range for width and height is from zero to 2048
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t SCISSOR_SIZE(const uint16_t width, const uint16_t height)
{
    uint32_t const widthv = (uint32_t) ((width & 0xFFFUL) << 12U);
    uint32_t const heightv = (uint32_t) (height & 0xFFFUL);
    return (DL_SCISSOR_SIZE | widthv | heightv);
}

/**
 * @brief Set the top left corner of the scissor clip rectangle.
 * @note valid range for width and height is from zero to 2047
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t SCISSOR_XY(const uint16_t xc0, const uint16_t yc0)
{
    uint32_t const xc0v = (uint32_t) ((xc0 & 0x7FFUL) << 11U);
    uint32_t const yc0v = (uint32_t) (yc0 & 0x7FFUL);
    return (DL_SCISSOR_XY | xc0v | yc0v);
}

/**
 * @brief Set function and reference value for stencil testing.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t STENCIL_FUNC(const uint8_t func, const uint8_t ref, const uint8_t mask)
{
    uint32_t const funcv = (uint32_t) ((func & 7UL) << 16U);
    uint32_t const refv = (uint32_t) ((ref & 0xFFUL) << 8U);
    uint32_t const maskv = (uint32_t) (mask & 0xFFUL);
    return (DL_STENCIL_FUNC | funcv | refv | maskv);
}

/**
 * @brief Control the writing of individual bits in the stencil planes.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t STENCIL_MASK(const uint8_t mask)
{
    return (DL_STENCIL_MASK | mask);
}

/**
 * @brief Set stencil test actions.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t STENCIL_OP(const uint8_t sfail, const uint8_t spass)
{
    uint32_t const sfailv = (uint32_t) ((sfail & 0x07UL) << 3U);
    uint32_t const spassv = (uint32_t) (spass & 0x07UL);
    return (DL_STENCIL_OP | sfailv | spassv);
}

/**
 * @brief Control the writing of the tag buffer.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t TAG_MASK(const uint8_t mask)
{
    return (DL_TAG_MASK | ((mask) & 1UL));
}

/**
 * @brief Set coordinates for graphics primitves.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t VERTEX2F(const int16_t xc0, const int16_t yc0)
{
    uint32_t const xc0v = ((((uint32_t) ((uint16_t) xc0)) & 0x7FFFUL) << 15U);
    uint32_t const yc0v = (((uint32_t) ((uint16_t) yc0)) & 0x7FFFUL);
    return (DL_VERTEX2F | xc0v | yc0v);
}

/**
 * @brief Set coordinates, bitmap-handle and cell-number for graphics primitves.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t VERTEX2II(const uint16_t xc0, const uint16_t yc0, const uint8_t handle, const uint8_t cell)
{
    uint32_t const xc0v = ((((uint32_t) xc0) & 0x1FFUL) << 21U);
    uint32_t const yc0v = ((((uint32_t) yc0) & 0x1FFUL) << 12U);
    uint32_t const handlev = ((((uint32_t) handle) & 0x1FUL) << 7U);
    uint32_t const cellv = (((uint32_t) cell) & 0x7FUL);
    return (DL_VERTEX2II | xc0v | yc0v | handlev | cellv);
}

/**
 * @brief Set the precision of VERTEX2F coordinates.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t VERTEX_FORMAT(const uint8_t frac)
{
    return (DL_VERTEX_FORMAT | ((frac) & 7UL));
}

/**
 * @brief Set the vertex transformations X translation component.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t VERTEX_TRANSLATE_X(const int32_t xco)
{
    return (DL_VERTEX_TRANSLATE_X | (((uint32_t) xco) & 0x1FFFFUL));
}

/**
 * @brief Set the vertex transformations Y translation component.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t VERTEX_TRANSLATE_Y(const int32_t yco)
{
    return (DL_VERTEX_TRANSLATE_Y | (((uint32_t) yco) & 0x1FFFFUL));
}

/* #define BEGIN(prim) ((DL_BEGIN) | ((prim) & 15UL)) */ /* use define DL_BEGIN */
/* #define DISPLAY() ((DL_DISPLAY)) */ /* use define DL_DISPLAY */
/* #define END() ((DL_END)) */ /* use define DL_END */
/* #define RESTORE_CONTEXT() ((DL_RESTORE_CONTEXT)) */ /* use define DL_RESTORE_CONTEXT */
/* #define RETURN() ((DL_RETURN)) */ /* use define DL_RETURN */
/* #define SAVE_CONTEXT() ((DL_SAVE_CONTEXT)) */ /* use define DL_SAVE_CONTEXT */
/* #define NOP() ((DL_NOP)) */


#define CLR_COL     ((uint8_t) 0x4U)
#define CLR_STN     ((uint8_t) 0x2U)
#define CLR_TAG     ((uint8_t) 0x1U)

/* Graphic command defines */
#define EVE_NEVER      ((uint8_t) 0UL)
#define EVE_LESS       ((uint8_t) 1UL)
#define EVE_LEQUAL     ((uint8_t) 2UL)
#define EVE_GREATER    ((uint8_t) 3UL)
#define EVE_GEQUAL     ((uint8_t) 4UL)
#define EVE_EQUAL      ((uint8_t) 5UL)
#define EVE_NOTEQUAL   ((uint8_t) 6UL)
#define EVE_ALWAYS     ((uint8_t) 7UL)

/* Bitmap formats */
#define EVE_ARGB1555        ((uint8_t) 0UL)
#define EVE_L1              ((uint8_t) 1UL)
#define EVE_L4              ((uint8_t) 2UL)
#define EVE_L8              ((uint8_t) 3UL)
#define EVE_RGB332          ((uint8_t) 4UL)
#define EVE_ARGB2           ((uint8_t) 5UL)
#define EVE_ARGB4           ((uint8_t) 6UL)
#define EVE_RGB565          ((uint8_t) 7UL)
#define EVE_BARGRAPH        ((uint8_t) 11UL)
#define EVE_PALETTED565     ((uint32_t) 14UL)
#define EVE_PALETTED4444    ((uint32_t) 15UL)
#define EVE_PALETTED8       ((uint32_t) 16UL)
#define EVE_L2              ((uint32_t) 17UL)


/* Bitmap filter types */
#define EVE_NEAREST    ((uint8_t) 0UL)
#define EVE_BILINEAR   ((uint8_t) 1UL)

/* Bitmap wrap types */
#define EVE_BORDER     ((uint8_t) 0UL)
#define EVE_REPEAT     ((uint8_t) 1UL)

/* Stencil defines */
#define EVE_KEEP       ((uint8_t) 1UL)
#define EVE_REPLACE    ((uint8_t) 2UL)
#define EVE_INCR       ((uint8_t) 3UL)
#define EVE_DECR       ((uint8_t) 4UL)
#define EVE_INVERT     ((uint8_t) 5UL)

/* Graphics display list swap defines */
#define EVE_DLSWAP_DONE   ((uint8_t) 0UL)
#define EVE_DLSWAP_LINE   ((uint8_t) 1UL)
#define EVE_DLSWAP_FRAME  ((uint8_t) 2UL)

/* Interrupt bits */
#define EVE_INT_SWAP          ((uint8_t) 0x01)
#define EVE_INT_TOUCH         ((uint8_t) 0x02)
#define EVE_INT_TAG           ((uint8_t) 0x04)
#define EVE_INT_SOUND         ((uint8_t) 0x08)
#define EVE_INT_PLAYBACK      ((uint8_t) 0x10)
#define EVE_INT_CMDEMPTY      ((uint8_t) 0x20)
#define EVE_INT_CMDFLAG       ((uint8_t) 0x40)
#define EVE_INT_CONVCOMPLETE  ((uint8_t) 0x80)

/* Touch mode */
#define EVE_TMODE_OFF        ((uint8_t) 0U)
#define EVE_TMODE_ONESHOT    ((uint8_t) 1U)
#define EVE_TMODE_FRAME      ((uint8_t) 2U)
#define EVE_TMODE_CONTINUOUS ((uint8_t) 3U)

/* Alpha blending */
#define EVE_ZERO                 ((uint32_t) 0UL)
#define EVE_ONE                  ((uint32_t) 1UL)
#define EVE_SRC_ALPHA            ((uint32_t) 2UL)
#define EVE_DST_ALPHA            ((uint32_t) 3UL)
#define EVE_ONE_MINUS_SRC_ALPHA  ((uint32_t) 4UL)
#define EVE_ONE_MINUS_DST_ALPHA  ((uint32_t) 5UL)

/* Graphics primitives */
#define EVE_BITMAPS              ((uint32_t) 1UL)
#define EVE_POINTS               ((uint32_t) 2UL)
#define EVE_LINES                ((uint32_t) 3UL)
#define EVE_LINE_STRIP           ((uint32_t) 4UL)
#define EVE_EDGE_STRIP_R         ((uint32_t) 5UL)
#define EVE_EDGE_STRIP_L         ((uint32_t) 6UL)
#define EVE_EDGE_STRIP_A         ((uint32_t) 7UL)
#define EVE_EDGE_STRIP_B         ((uint32_t) 8UL)
#define EVE_RECTS                ((uint32_t) 9UL)

#define EVE_INT_G8               ((uint32_t) 18UL)
#define EVE_INT_L8C              ((uint32_t) 12UL)
#define EVE_INT_VGA              ((uint32_t) 13UL)

/* Widget command options */
#define EVE_OPT_MONO             ((uint16_t) 1U)
#define EVE_OPT_NODL             ((uint16_t) 2U)
#define EVE_OPT_FLAT             ((uint16_t) 256U)
#define EVE_OPT_CENTERX          ((uint16_t) 512U)
#define EVE_OPT_CENTERY          ((uint16_t) 1024U)
#define EVE_OPT_CENTER           (EVE_OPT_CENTERX | EVE_OPT_CENTERY)
#define EVE_OPT_NOBACK           ((uint16_t) 4096U)
#define EVE_OPT_NOTICKS          ((uint16_t) 8192U)
#define EVE_OPT_NOHM             ((uint16_t) 16384U)
#define EVE_OPT_NOPOINTER        ((uint16_t) 16384U)
#define EVE_OPT_NOSECS           ((uint16_t) 32768U)
#define EVE_OPT_NOHANDS          ((uint16_t) 49152U)
#define EVE_OPT_RIGHTX           ((uint16_t) 2048U)
#define EVE_OPT_SIGNED           ((uint16_t) 256U)

#define EVE_OPT_MEDIAFIFO        ((uint16_t) 16U)
#define EVE_OPT_FULLSCREEN       ((uint16_t) 8U)
#define EVE_OPT_NOTEAR           ((uint16_t) 4U)
#define EVE_OPT_SOUND            ((uint16_t) 32U)


/* BT820 */
#if EVE_GEN > 4
/* quite a number of things are not compatible to EVE2/EVE3/EVE4 */

/* Memory */
#define EVE_RAM_G           ((uint32_t) 0x00000000UL)
#define EVE_RAM_CMD         ((uint32_t) 0x7F000000UL)
#define EVE_REG_CORE_R2     ((uint32_t) 0x7F004000UL)
#define EVE_RAM_ERR_REPORT  ((uint32_t) 0x7F004800UL)
#define EVE_REG_CORE_R1     ((uint32_t) 0x7F006000UL)
#define EVE_RAM_DL          ((uint32_t) 0x7F008000UL)
#define REG_LVDSTX          ((uint32_t) 0x7F800300UL)
#define REG_SYS             ((uint32_t) 0x7F800400UL)
#define REG_LVDSRX          ((uint32_t) 0x7F800500UL)
#define REG_I2S             ((uint32_t) 0x7F800800UL)

/* Memory buffer sizes */
#define EVE_RAM_G_SIZE      ((uint32_t) 125U*1024U*1024UL) /* top 2.5MiB of system memory are reserved */
#define EVE_CMD_FIFO_SIZE   ((uint32_t) 16U*1024UL)
#define EVE_RAM_DL_SIZE     ((uint32_t) 16U*1024UL)

#define EVE_CMD_FIFO_FULL ((uint16_t) 0x3ffcU)
#define EVE_CMD_FIFO_HALF ((uint16_t) 0x2000U)

/* diplay list commands, most need OR's arguments */
#define DL_BITMAP_EXT_FORMAT    ((uint32_t) 0x2E000000UL)
#define DL_BITMAP_SWIZZLE       ((uint32_t) 0x2F000000UL)
#define DL_BITMAP_SOURCEH       ((uint32_t) 0x31000000UL)
#define DL_PALETTE_SOURCEH      ((uint32_t) 0x32000000UL)
#define DL_BITMAP_ZORDER        ((uint32_t) 0x33000000UL)
#define DL_REGION               ((uint32_t) 0x34000000UL)

/* used with BITMAP_LAYOUT or CMD_SETBITMAP to indicate bitmap-format */
#define EVE_RGB8            ((uint8_t) 19UL)
#define EVE_ARGB8           ((uint8_t) 20UL)
#define EVE_PALETTEDARGB8   ((uint8_t) 21UL)
#define EVE_RGB6            ((uint8_t) 22UL)
#define EVE_ARGB6           ((uint8_t) 23UL)
#define EVE_LA1             ((uint8_t) 24UL)
#define EVE_LA2             ((uint8_t) 25UL)
#define EVE_LA4             ((uint8_t) 26UL)
#define EVE_LA8             ((uint8_t) 27UL)
#define EVE_YCBCR           ((uint8_t) 28UL)
#define EVE_GLFORMAT        ((uint8_t) 31UL) /* used with BITMAP_LAYOUT to indicate bitmap-format is specified by BITMAP_EXT_FORMAT */

/* used with CMD_SETBITMAP to indicate bitmap-format */
#define EVE_ASTC_4X4   ((uint32_t) 37808UL)
#define EVE_ASTC_5X4   ((uint32_t) 37809UL)
#define EVE_ASTC_5X5   ((uint32_t) 37810UL)
#define EVE_ASTC_6X5   ((uint32_t) 37811UL)
#define EVE_ASTC_6X6   ((uint32_t) 37812UL)
#define EVE_ASTC_8X5   ((uint32_t) 37813UL)
#define EVE_ASTC_8X6   ((uint32_t) 37814UL)
#define EVE_ASTC_8X8   ((uint32_t) 37815UL)
#define EVE_ASTC_10X5  ((uint32_t) 37816UL)
#define EVE_ASTC_10X6  ((uint32_t) 37817UL)
#define EVE_ASTC_10X8  ((uint32_t) 37818UL)
#define EVE_ASTC_10X10 ((uint32_t) 37819UL)
#define EVE_ASTC_12X10 ((uint32_t) 37820UL)
#define EVE_ASTC_12X12 ((uint32_t) 37821UL)

#define EVE_OPT_FLASH   ((uint16_t) 64U)
#define EVE_OPT_FS      ((uint16_t) 0x2000U)

#define EVE_OPT_RGB565      ((uint16_t) 0U)
#define EVE_OPT_TRUECOLOR   ((uint16_t) 0x0200U)
#define EVE_OPT_YCBCR5      ((uint16_t) 0x0400U)

#define EVE_OPT_OVERLAY ((uint16_t) 128U)
#define EVE_OPT_FORMAT ((uint16_t) 4096U)
#define EVE_OPT_FILL   ((uint16_t) 8192U)

#define EVE_OPT_4BIT            ((uint16_t) 0x0002U)
#define EVE_OPT_HALFSPEED       ((uint16_t) 0x0004U)
#define EVE_OPT_QUARTERSPEED    ((uint16_t) 0x0008U)
#define EVE_OPT_IS_MMC          ((uint16_t) 0x0010U)
#define EVE_OPT_IS_SD           ((uint16_t) 0x0020U)

#define EVE_OPT_SFNLOWER        ((uint16_t) 0x0001U)
#define EVE_OPT_CASESENSITIVE   ((uint16_t) 0x0002U)
#define EVE_OPT_DIRSEP_WIN      ((uint16_t) 0x0004U)
#define EVE_OPT_DIRSEP_UNIX     ((uint16_t) 0x0008U)

#define EVE_SD_FAIL_NO_CARD_DETECTED    ((uint16_t) 0xd000U)
#define EVE_SD_FAIL_NO_RESPONSE         ((uint16_t) 0xd001U)
#define EVE_SD_FAIL_CARD_TIMEOUT        ((uint16_t) 0xd002U)
#define EVE_SD_FAIL_NO_MBR_FOUND        ((uint16_t) 0xd003U)
#define EVE_SD_FAIL_FAT_NOT_FOUND       ((uint16_t) 0xd004U)
#define EVE_SD_FAIL_ENTER_HIGHSPEED     ((uint16_t) 0xd005U)

#define EVE_FS_FAIL_FILE_NOT_FOUND      ((uint16_t) 2U)
#define EVE_FS_FAIL_IO_ERROR            ((uint16_t) 5U)
#define EVE_FS_FAIL_BUFFER_TOO_SMALL    ((uint16_t) 12U)

#define EVE_CORNER_ZERO ((uint32_t) 0UL)
#define EVE_EDGE_ZERO   ((uint32_t) 1UL)

#define EVE_SWAPCHAIN_0     ((uint32_t) 0xffff00ffUL)
#define EVE_SWAPCHAIN_1     ((uint32_t) 0xffff01ffUL)
#define EVE_SWAPCHAIN_2     ((uint32_t) 0xffff02ffUL)
#define EVE_SO_MODE_1       ((uint32_t) 0UL)
#define EVE_SO_MODE_2       ((uint32_t) 1UL)
#define EVE_SO_MODE_3       ((uint32_t) 2UL)
#define EVE_SO_MODE_4       ((uint32_t) 3UL)

#define BITS_2BIT_MASK ((uint8_t)0x03U)
#define BITS_3BIT_MASK ((uint8_t)0x07U)
#define BITS_4BIT_MASK ((uint8_t)0x0fU)
#define BITS_7BIT_MASK ((uint8_t)0x7fU)
#define BITS_12BIT_MASK ((uint16_t)0xfffU)

#define SETLVDSPLL_CPS_POS      (25U)
#define SETLVDSPLL_PERIOD_POS   (13U)
#define SETLVDSPLL_RANGE_POS    (11U)
#define SETLVDSPLL_MUL_POS  (4U)
#define SETLVDSPLL_CLKDIV_POS   (0U)

#define PLL_LOCK_PERIOD ((uint32_t) 384UL) /* reset default value */

static inline uint32_t setlvdspll_value(const uint8_t cps, const uint16_t period, const uint8_t range, const uint8_t mul, const uint8_t clkdiv)
{
    const uint32_t cpsv = ((uint32_t)(cps & BITS_2BIT_MASK) << SETLVDSPLL_CPS_POS);
    const uint32_t periodv = ((uint32_t)(period & BITS_12BIT_MASK) << SETLVDSPLL_PERIOD_POS);
    const uint32_t rangev = ((uint32_t)(range & BITS_2BIT_MASK) << SETLVDSPLL_RANGE_POS);
    const uint32_t mulv = ((uint32_t)(mul & BITS_7BIT_MASK) << SETLVDSPLL_MUL_POS);
    const uint32_t clkdivv = ((uint32_t)(clkdiv & BITS_4BIT_MASK) << SETLVDSPLL_CLKDIV_POS);
    return (cpsv | periodv | rangev | mulv | clkdivv);
}

#define LVDS_CH0_EN ((uint32_t) 2UL)
#define LVDS_CH1_EN ((uint32_t) 4UL)


/* Host commands */
#define EVE_ACTIVE          ((uint8_t) 0x00U) /* place EVE in active state */
#define EVE_STANDBY         ((uint8_t) 0xE0U) /* place EVE in Standby (clk running) */
#define EVE_SLEEP           ((uint8_t) 0xE1U) /* place EVE in Sleep (clk off) */
#define EVE_PWRDOWN         ((uint8_t) 0xE2U) /* place EVE in Power Down (core off) */
#define EVE_SETPLLSP1       ((uint8_t) 0xE4U) /* change the system PLL frequency */
#define EVE_SETSYSCLKDIV    ((uint8_t) 0xE6U) /* change the system clock frequency */
#define EVE_SETBOOTCFG      ((uint8_t) 0xE8U) /* configure the REG_BOOT_CFG register to control the boot sequence */
#define EVE_BOOTCFGEN       ((uint8_t) 0xE9U) /* safety mechanism: allow or deny configuration of REG_BOOT_CFG and REG_DDR_TYPE */
#define EVE_SETDDRTYPE      ((uint8_t) 0xEBU) /* programs the DDR DRAM type definition register, REG_DDR_TYPE */

#define SETBOOTCFG_DDR_EN       ((uint8_t)(1U << 7U))
#define SETBOOTCFG_TOUCH_EN     ((uint8_t)(1U << 6U))
#define SETBOOTCFG_AUDIO_EN     ((uint8_t)(1U << 5U))
#define SETBOOTCFG_WDG_EN       ((uint8_t)(1U << 4U))

#define BOOTCFGEN_BOOT_USER_SETTING     ((uint8_t)(1U << 7U))
#define BOOTCFGEN_DDRTYPE_USER_SETTING  ((uint8_t)(1U << 6U))
#define BOOTCFGEN_ALLOW                 ((uint8_t)(1U << 0U))

#define SETDDRTYPE_SPEED_POS    (5U)
#define SETDDRTYPE_TYPE_POS     (3U)
#define SETDDRTYPE_SIZE_POS     (0U)

#define SETDDRTYPE_SPEED_1333   (0U)
#define SETDDRTYPE_SPEED_1066   (1U)
#define SETDDRTYPE_SPEED_933    (2U)
#define SETDDRTYPE_SPEED_800    (3U)

#define SETDDRTYPE_TYPE_DDR3    (0U)
#define SETDDRTYPE_TYPE_DDR3L   (1U)
#define SETDDRTYPE_TYPE_LPDDR2  (2U)

#define SETDDRTYPE_SIZE_1024    (0U)
#define SETDDRTYPE_SIZE_2048    (1U)
#define SETDDRTYPE_SIZE_4096    (2U)
#define SETDDRTYPE_SIZE_8192    (3U)
#define SETDDRTYPE_SIZE_512     (4U)

static inline uint8_t setddrtype_value(const uint8_t speed, const uint8_t type, const uint8_t size)
{
    const uint8_t speedv = ((speed & BITS_3BIT_MASK) << SETDDRTYPE_SPEED_POS);
    const uint8_t typev = ((type & BITS_2BIT_MASK) << SETDDRTYPE_TYPE_POS);
    const uint8_t sizev = ((size & BITS_2BIT_MASK) << SETDDRTYPE_SIZE_POS);
    return (speedv | typev | sizev);
}


/* Inline functions that work like the function-like macros from Bridgetek: */

/**
 * @brief Set the extended format of the bitmap.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t BITMAP_EXT_FORMAT(const uint16_t format)
{
    return (DL_BITMAP_EXT_FORMAT | format);
}

/**
 * @brief Set the bitmap handle.
 * @return a 32 bit word for use with EVE_cmd_dl()
 * @note BT82x increased the number of bitmap handles to 64
 */
static inline uint32_t BITMAP_HANDLE(const uint8_t handle)
{
    return (DL_BITMAP_HANDLE | ((handle) & 0x3FUL));
}

/**
 * @brief Set the source address of bitmap data in RAM_G or flash memory.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t BITMAP_SOURCEH(const uint32_t addr)
{
    return (DL_BITMAP_SOURCEH | (addr & 0x3FFFFFUL));
}

/**
 * @brief Set the source for the red, green, blue and alpha channels of a bitmap.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t BITMAP_SWIZZLE(const uint8_t red, const uint8_t green, const uint8_t blue, const uint8_t alpha)
{
    uint32_t const redv = ((red & 7UL) << 9U);
    uint32_t const greenv = ((green & 7UL) << 6U);
    uint32_t const bluev = ((blue & 7UL) << 3U);
    uint32_t const alphav = (alpha & 7UL);
    return (DL_BITMAP_SWIZZLE | redv | greenv | bluev | alphav);
}

/**
 * @brief Set the A coefficient of the bitmap transform matrix.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t BITMAP_TRANSFORM_A(const uint8_t prc, const uint32_t val)
{
    uint32_t const prcv = ((prc & 1UL) << 17U);
    uint32_t const valv = (val & 0x1FFFFUL);
    return (DL_BITMAP_TRANSFORM_A | prcv | valv);
}

/**
 * @brief Set the B coefficient of the bitmap transform matrix.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t BITMAP_TRANSFORM_B(const uint8_t prc, const uint32_t val)
{
    uint32_t const prcv = ((prc & 1UL) << 17U);
    uint32_t const valv = (val & 0x1FFFFUL);
    return (DL_BITMAP_TRANSFORM_B | prcv | valv);
}

/**
 * @brief Set the D coefficient of the bitmap transform matrix.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t BITMAP_TRANSFORM_D(const uint8_t prc, const uint32_t val)
{
    uint32_t const prcv = ((prc & 1UL) << 17U);
    uint32_t const valv = (val & 0x1FFFFUL);
    return (DL_BITMAP_TRANSFORM_D | prcv | valv);
}

/**
 * @brief Set the E coefficient of the bitmap transform matrix.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t BITMAP_TRANSFORM_E(const uint8_t prc, const uint32_t val)
{
    uint32_t const prcv = ((prc & 1UL) << 17U);
    uint32_t const valv = (val & 0x1FFFFUL);
    return (DL_BITMAP_TRANSFORM_E | prcv | valv);
}

/**
 * @brief Set the z-order address pattern for a bitmap.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t BITMAP_ZORDER(const uint8_t val)
{
    return (DL_BITMAP_ZORDER | val);
}

/**
 * @brief Execute a sequence of commands at another location in the display list.
 * @note valid range for dest is from zero to 4095
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t CALL(const uint16_t dest)
{
    return (DL_CALL | (dest & 0xFFFUL));
}

/**
 * @brief Set clear value for the tag buffer.
 * @return a 32 bit word for use with EVE_cmd_dl()
 * @note BT82x increased the range of the tag value to 24 bits
 */
static inline uint32_t CLEAR_TAG(const uint32_t val)
{
    return (DL_CLEAR_TAG | (val & 0x00FFFFFFUL));
}

/**
 * @brief Execute commands at another location in the display list.
 * @note valid range for dest is from zero to 4095
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t JUMP(const uint16_t dest)
{
    return (DL_JUMP | (dest & 0xFFFUL));
}

/**
 * @brief Set the base address of the palette.
 * @note 2-byte alignment is required if pixel format is PALETTE4444 or PALETTE565.
 * @return a 32 bit word for use with EVE_cmd_dl()
 * @note BT82x increased the range of the address for this command to 24 bits
 */
static inline uint32_t PALETTE_SOURCE(const uint32_t addr)
{
    return (DL_PALETTE_SOURCE | (addr & 0x00FFFFFFUL));
}

/**
 * @brief Set the high part of the base address of the palette.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t PALETTE_SOURCEH(const uint8_t addr)
{
    return (DL_PALETTE_SOURCE | addr);
}

/**
 * @brief Define the current drawing region.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t REGION(const uint8_t start, const uint8_t height, const uint16_t dest)
{
    uint32_t const startv = ((start & 0x3FUL) << 18U);
    uint32_t const heightv = ((height & 0x3FL) << 12U);
    uint32_t const destv = (dest & 0xFFFL);
    return (DL_REGION | startv | heightv | destv);
}

/**
 * @brief Attach the tag value for the following graphics objects drawn on the screen.
 * @return a 32 bit word for use with EVE_cmd_dl()
 * @note BT82x increased the range of the tag value to 24 bits
 */
static inline uint32_t TAG(const uint32_t tagval)
{
    return (DL_TAG | (tagval & 0x00FFFFFFUL));
}

/* Registers */
#define REG_ANIM_ACTIVE         ((uint32_t) 0x7F00402CUL)
#define REG_AUD_PWM             ((uint32_t) 0x7F00613CUL)
#define REG_BOOT_CFG            ((uint32_t) 0x7F006628UL)
#define REG_BOOT_STATUS         ((uint32_t) 0x7F80044CUL)
#define REG_CHIP_ID             ((uint32_t) 0x7F800448UL)
#define REG_CLOCK               ((uint32_t) 0x7F006008UL)
#define REG_CMD_DL              ((uint32_t) 0x7F006154UL)
#define REG_CMD_READ            ((uint32_t) 0x7F00614CUL)
#define REG_CMD_WRITE           ((uint32_t) 0x7F006150UL)
#define REG_CMDB_SPACE          ((uint32_t) 0x7F006594UL)
#define REG_CMDB_WRITE          ((uint32_t) 0x7F010000UL)
#define REG_CPURESET            ((uint32_t) 0x7F006088UL)
#define REG_CTOUCH_EXTENDED     ((uint32_t) 0x7F00615CUL)
#define REG_CTOUCH_TOUCH0_XY    ((uint32_t) 0x7F006160UL)
#define REG_CTOUCH_TOUCH4_XY    ((uint32_t) 0x7F006170UL)
#define REG_CTOUCH_TOUCHA_XY    ((uint32_t) 0x7F006164UL)
#define REG_CTOUCH_TOUCHB_XY    ((uint32_t) 0x7F006168UL)
#define REG_CTOUCH_TOUCHC_XY    ((uint32_t) 0x7F00616CUL)
#define REG_DDR_TYPE            ((uint32_t) 0x7F800454UL)
#define REG_DISP                ((uint32_t) 0x7F0060E4UL)
#define REG_DLSWAP              ((uint32_t) 0x7F0060B4UL)
#define REG_EXTENT_X0           ((uint32_t) 0x7F00403CUL)
#define REG_EXTENT_X1           ((uint32_t) 0x7F004044UL)
#define REG_EXTENT_Y0           ((uint32_t) 0x7F004040UL)
#define REG_EXTENT_Y1           ((uint32_t) 0x7F004048UL)
#define REG_FLASH_SIZE          ((uint32_t) 0x7F004024UL)
#define REG_FLASH_STATUS        ((uint32_t) 0x7F0065D4UL)
#define REG_FRAMES              ((uint32_t) 0x7F006004UL)
#define REG_FREQUENCY           ((uint32_t) 0x7F00600CUL)
#define REG_GPIO                ((uint32_t) 0x7F0060E0UL)
#define REG_GPIO_DIR            ((uint32_t) 0x7F0060DCUL)
#define REG_HCYCLE              ((uint32_t) 0x7F00608CUL)
#define REG_HOFFSET             ((uint32_t) 0x7F006090UL)
#define REG_HSIZE               ((uint32_t) 0x7F006094UL)
#define REG_HSYNC0              ((uint32_t) 0x7F006098UL)
#define REG_HSYNC1              ((uint32_t) 0x7F00609CUL)
#define REG_I2S_CFG             ((uint32_t) 0x7F800800UL)
#define REG_I2S_CTL             ((uint32_t) 0x7F800804UL)
#define REG_I2S_EN              ((uint32_t) 0x7F006714UL)
#define REG_I2S_FREQ            ((uint32_t) 0x7F006718UL)
#define REG_I2S_PAD_CFG         ((uint32_t) 0x7F800814UL)
#define REG_I2S_STAT            ((uint32_t) 0x7F800810UL)
#define REG_ID                  ((uint32_t) 0x7F006000UL)
#define REG_INT_EN              ((uint32_t) 0x7F006104UL)
#define REG_INT_FLAGS           ((uint32_t) 0x7F006100UL)
#define REG_INT_MASK            ((uint32_t) 0x7F006108UL)
#define REG_LVDSRX_CORE_CAPTURE ((uint32_t) 0x7F006674UL)
#define REG_LVDSRX_CORE_DEST    ((uint32_t) 0x7F00667CUL)
#define REG_LVDSRX_CORE_DITHER  ((uint32_t) 0x7F006684UL)
#define REG_LVDSRX_CORE_ENABLE  ((uint32_t) 0x7F006670UL)
#define REG_LVDSRX_CORE_FORMAT  ((uint32_t) 0x7F006680UL)
#define REG_LVDSRX_CORE_SETUP   ((uint32_t) 0x7F006678UL)
#define REG_LVDSRX_CTRL         ((uint32_t) 0x7F800504UL)
#define REG_LVDSRX_SETUP        ((uint32_t) 0x7F800500UL)
#define REG_LVDSRX_STAT         ((uint32_t) 0x7F800508UL)
#define REG_LVDSTX_CTRL_CH0     ((uint32_t) 0x7F800314UL)
#define REG_LVDSTX_CTRL_CH1     ((uint32_t) 0x7F800318UL)
#define REG_LVDSTX_EN           ((uint32_t) 0x7F800300UL)
#define REG_LVDSTX_ERR_STAT     ((uint32_t) 0x7F800320UL)
#define REG_LVDSTX_PLLCFG       ((uint32_t) 0x7F800304UL)
#define REG_LVDSTX_STAT         ((uint32_t) 0x7F80031CUL)
#define REG_MACRO_0             ((uint32_t) 0x7F006130UL)
#define REG_MACRO_1             ((uint32_t) 0x7F006134UL)
#define REG_MEDIAFIFO_READ      ((uint32_t) 0x7F004014UL)
#define REG_MEDIAFIFO_WRITE     ((uint32_t) 0x7F004018UL)
#define REG_OBJECT_COMPLETE     ((uint32_t) 0x7F004038UL)
#define REG_PCLK_POL            ((uint32_t) 0x7F0060B8UL)
#define REG_PIN_DRV_0           ((uint32_t) 0x7F800408UL)
#define REG_PIN_DRV_1           ((uint32_t) 0x7F80040CUL)
#define REG_PIN_DRV_2           ((uint32_t) 0x7F800464UL)
#define REG_PIN_SLEW_0          ((uint32_t) 0x7F800410UL)
#define REG_PIN_SLEW_1          ((uint32_t) 0x7F800468UL)
#define REG_PIN_TYPE_0          ((uint32_t) 0x7F800414UL)
#define REG_PIN_TYPE_1          ((uint32_t) 0x7F800418UL)
#define REG_PIN_TYPE_2          ((uint32_t) 0x7F80046CUL)
#define REG_PLAY                ((uint32_t) 0x7F0060D8UL)
#define REG_PLAY_CONTROL        ((uint32_t) 0x7F004050UL)
#define REG_PLAYBACK_FORMAT     ((uint32_t) 0x7F00611CUL)
#define REG_PLAYBACK_FREQ       ((uint32_t) 0x7F006118UL)
#define REG_PLAYBACK_LENGTH     ((uint32_t) 0x7F006110UL)
#define REG_PLAYBACK_LOOP       ((uint32_t) 0x7F006120UL)
#define REG_PLAYBACK_PAUSE      ((uint32_t) 0x7F0065D0UL)
#define REG_PLAYBACK_PLAY       ((uint32_t) 0x7F006124UL)
#define REG_PLAYBACK_READPTR    ((uint32_t) 0x7F006114UL)
#define REG_PLAYBACK_START      ((uint32_t) 0x7F00610CUL)
#define REG_PWM_DUTY            ((uint32_t) 0x7F00612CUL)
#define REG_PWM_HZ              ((uint32_t) 0x7F006128UL)
#define REG_RE_ACTIVE           ((uint32_t) 0x7F006028UL)
#define REG_RE_DEST             ((uint32_t) 0x7F006010UL)
#define REG_RE_DITHER           ((uint32_t) 0x7F006024UL)
#define REG_RE_FORMAT           ((uint32_t) 0x7F006014UL)
#define REG_RE_H                ((uint32_t) 0x7F006020UL)
#define REG_RE_RENDERS          ((uint32_t) 0x7F00602CUL)
#define REG_RE_ROTATE           ((uint32_t) 0x7F006018UL)
#define REG_RE_W                ((uint32_t) 0x7F00601CUL)
#define REG_SC0_PTR0            ((uint32_t) 0x7F00603CUL)
#define REG_SC0_PTR1            ((uint32_t) 0x7F006040UL)
#define REG_SC0_PTR2            ((uint32_t) 0x7F006044UL)
#define REG_SC0_PTR3            ((uint32_t) 0x7F006048UL)
#define REG_SC0_RESET           ((uint32_t) 0x7F006034UL)
#define REG_SC0_SIZE            ((uint32_t) 0x7F006038UL)
#define REG_SC1_PTR0            ((uint32_t) 0x7F006054UL)
#define REG_SC1_PTR1            ((uint32_t) 0x7F006058UL)
#define REG_SC1_PTR2            ((uint32_t) 0x7F00605CUL)
#define REG_SC1_PTR3            ((uint32_t) 0x7F006060UL)
#define REG_SC1_RESET           ((uint32_t) 0x7F00604CUL)
#define REG_SC1_SIZE            ((uint32_t) 0x7F006050UL)
#define REG_SC2_ADDR            ((uint32_t) 0x7F006784UL)
#define REG_SC2_PTR0            ((uint32_t) 0x7F00606CUL)
#define REG_SC2_PTR1            ((uint32_t) 0x7F006070UL)
#define REG_SC2_PTR2            ((uint32_t) 0x7F006074UL)
#define REG_SC2_PTR3            ((uint32_t) 0x7F006078UL)
#define REG_SC2_RESET           ((uint32_t) 0x7F006064UL)
#define REG_SC2_SIZE            ((uint32_t) 0x7F006068UL)
#define REG_SC2_STATUS          ((uint32_t) 0x7F006780UL)
#define REG_SO_EN               ((uint32_t) 0x7F006600UL)
#define REG_SO_FORMAT           ((uint32_t) 0x7F0065FCUL)
#define REG_SO_MODE             ((uint32_t) 0x7F0065F4UL)
#define REG_SO_SOURCE           ((uint32_t) 0x7F0065F8UL)
#define REG_SOUND               ((uint32_t) 0x7F0060D4UL)
#define REG_SYS_CFG             ((uint32_t) 0x7F800420UL)
#define REG_SYS_STAT            ((uint32_t) 0x7F800424UL)
#define REG_TAG                 ((uint32_t) 0x7F0060C4UL)
#define REG_TAG_X               ((uint32_t) 0x7F0060BCUL)
#define REG_TAG_Y               ((uint32_t) 0x7F0060C0UL)
#define REG_TOUCH_CONFIG        ((uint32_t) 0x7F0061B4UL)
#define REG_TOUCH_MODE          ((uint32_t) 0x7F006158UL)
#define REG_TOUCH_RAW_XY        ((uint32_t) 0x7F006164UL)
#define REG_TOUCH_SCREEN_XY     ((uint32_t) 0x7F006160UL)
#define REG_TOUCH_TAG           ((uint32_t) 0x7F006178UL)
#define REG_TOUCH_TAG_XY        ((uint32_t) 0x7F006174UL)
#define REG_TOUCH_TAG1          ((uint32_t) 0x7F006180UL)
#define REG_TOUCH_TAG1_XY       ((uint32_t) 0x7F00617CUL)
#define REG_TOUCH_TAG2          ((uint32_t) 0x7F006188UL)
#define REG_TOUCH_TAG2_XY       ((uint32_t) 0x7F006184UL)
#define REG_TOUCH_TAG3          ((uint32_t) 0x7F006190UL)
#define REG_TOUCH_TAG3_XY       ((uint32_t) 0x7F00618CUL)
#define REG_TOUCH_TAG4          ((uint32_t) 0x7F006198UL)
#define REG_TOUCH_TAG4_XY       ((uint32_t) 0x7F006194UL)
#define REG_TOUCH_TRANSFORM_A   ((uint32_t) 0x7F00619CUL)
#define REG_TOUCH_TRANSFORM_B   ((uint32_t) 0x7F0061A0UL)
#define REG_TOUCH_TRANSFORM_C   ((uint32_t) 0x7F0061A4UL)
#define REG_TOUCH_TRANSFORM_D   ((uint32_t) 0x7F0061A8UL)
#define REG_TOUCH_TRANSFORM_E   ((uint32_t) 0x7F0061ACUL)
#define REG_TOUCH_TRANSFORM_F   ((uint32_t) 0x7F0061B0UL)
#define REG_TRACKER             ((uint32_t) 0x7F004000UL)
#define REG_TRACKER_1           ((uint32_t) 0x7F004004UL)
#define REG_TRACKER_2           ((uint32_t) 0x7F004008UL)
#define REG_TRACKER_3           ((uint32_t) 0x7F00400CUL)
#define REG_TRACKER_4           ((uint32_t) 0x7F004010UL)
#define REG_VCYCLE              ((uint32_t) 0x7F0060A0UL)
#define REG_VOFFSET             ((uint32_t) 0x7F0060A4UL)
#define REG_VOL_L_PB            ((uint32_t) 0x7F0060C8UL)
#define REG_VOL_R_PB            ((uint32_t) 0x7F0060CCUL)
#define REG_VOL_SOUND           ((uint32_t) 0x7F0060D0UL)
#define REG_VSIZE               ((uint32_t) 0x7F0060A8UL)
#define REG_VSYNC0              ((uint32_t) 0x7F0060ACUL)
#define REG_VSYNC1              ((uint32_t) 0x7F0060B0UL)

/* Commands */
#define CMD_ANIMDRAW            ((uint32_t) 0xFFFFFF4FUL)
#define CMD_ANIMFRAME           ((uint32_t) 0xFFFFFF5EUL)
#define CMD_ANIMSTART           ((uint32_t) 0xFFFFFF5FUL)
#define CMD_ANIMSTOP            ((uint32_t) 0xFFFFFF4DUL)
#define CMD_ANIMXY              ((uint32_t) 0xFFFFFF4EUL)
#define CMD_APPEND              ((uint32_t) 0xFFFFFF1CUL)
#define CMD_APPENDF             ((uint32_t) 0xFFFFFF52UL)
#define CMD_ARC                 ((uint32_t) 0xFFFFFF87UL)
#define CMD_BGCOLOR             ((uint32_t) 0xFFFFFF07UL)
#define CMD_BITMAP_TRANSFORM    ((uint32_t) 0xFFFFFF1FUL)
#define CMD_BUTTON              ((uint32_t) 0xFFFFFF0BUL)
#define CMD_CALIBRATE           ((uint32_t) 0xFFFFFF13UL)
#define CMD_CALIBRATESUB        ((uint32_t) 0xFFFFFF56UL)
#define CMD_CALLLIST            ((uint32_t) 0xFFFFFF5BUL)
#define CMD_CGRADIENT           ((uint32_t) 0xFFFFFF8AUL)
#define CMD_CLOCK               ((uint32_t) 0xFFFFFF12UL)
#define CMD_COLDSTART           ((uint32_t) 0xFFFFFF2EUL)
#define CMD_COPYLIST            ((uint32_t) 0xFFFFFF88UL)
#define CMD_DDRSHUTDOWN         ((uint32_t) 0xFFFFFF65UL)
#define CMD_DDRSTARTUP          ((uint32_t) 0xFFFFFF66UL)
#define CMD_DIAL                ((uint32_t) 0xFFFFFF29UL)
#define CMD_DLSTART             ((uint32_t) 0xFFFFFF00UL)
#define CMD_ENABLEREGION        ((uint32_t) 0xFFFFFF7EUL)
#define CMD_ENDLIST             ((uint32_t) 0xFFFFFF5DUL)
#define CMD_FENCE               ((uint32_t) 0xFFFFFF68UL)
#define CMD_FGCOLOR             ((uint32_t) 0xFFFFFF08UL)
#define CMD_FILLWIDTH           ((uint32_t) 0xFFFFFF51UL)
#define CMD_FLASHATTACH         ((uint32_t) 0xFFFFFF43UL)
#define CMD_FLASHDETACH         ((uint32_t) 0xFFFFFF42UL)
#define CMD_FLASHERASE          ((uint32_t) 0xFFFFFF3EUL)
#define CMD_FLASHFAST           ((uint32_t) 0xFFFFFF44UL)
#define CMD_FLASHPROGRAM        ((uint32_t) 0xFFFFFF64UL)
#define CMD_FLASHREAD           ((uint32_t) 0xFFFFFF40UL)
#define CMD_FLASHSOURCE         ((uint32_t) 0xFFFFFF48UL)
#define CMD_FLASHSPIDESEL       ((uint32_t) 0xFFFFFF45UL)
#define CMD_FLASHSPIRX          ((uint32_t) 0xFFFFFF47UL)
#define CMD_FLASHSPITX          ((uint32_t) 0xFFFFFF46UL)
#define CMD_FLASHUPDATE         ((uint32_t) 0xFFFFFF41UL)
#define CMD_FLASHWRITE          ((uint32_t) 0xFFFFFF3FUL)
#define CMD_FSDIR               ((uint32_t) 0xFFFFFF8EUL)
#define CMD_FSOPTIONS           ((uint32_t) 0xFFFFFF6DUL)
#define CMD_FSREAD              ((uint32_t) 0xFFFFFF71UL)
#define CMD_FSSIZE              ((uint32_t) 0xFFFFFF80UL)
#define CMD_FSSOURCE            ((uint32_t) 0xFFFFFF7FUL)
#define CMD_GAUGE               ((uint32_t) 0xFFFFFF11UL)
#define CMD_GETIMAGE            ((uint32_t) 0xFFFFFF58UL)
#define CMD_GETMATRIX           ((uint32_t) 0xFFFFFF2FUL)
#define CMD_GETPROPS            ((uint32_t) 0xFFFFFF22UL)
#define CMD_GETPTR              ((uint32_t) 0xFFFFFF20UL)
#define CMD_GLOW                ((uint32_t) 0xFFFFFF8BUL)
#define CMD_GRADCOLOR           ((uint32_t) 0xFFFFFF30UL)
#define CMD_GRADIENT            ((uint32_t) 0xFFFFFF09UL)
#define CMD_GRADIENTA           ((uint32_t) 0xFFFFFF50UL)
#define CMD_GRAPHICSFINISH      ((uint32_t) 0xFFFFFF6BUL)
#define CMD_I2SSTARTUP          ((uint32_t) 0xFFFFFF69UL)
#define CMD_INFLATE             ((uint32_t) 0xFFFFFF4AUL)
#define CMD_INTERRUPT           ((uint32_t) 0xFFFFFF02UL)
#define CMD_KEYS                ((uint32_t) 0xFFFFFF0CUL)
#define CMD_LOADASSET           ((uint32_t) 0xFFFFFF81UL)
#define CMD_LOADIDENTITY        ((uint32_t) 0xFFFFFF23UL)
#define CMD_LOADIMAGE           ((uint32_t) 0xFFFFFF21UL)
#define CMD_LOADWAV             ((uint32_t) 0xFFFFFF85UL)
#define CMD_LOGO                ((uint32_t) 0xFFFFFF2DUL)
#define CMD_MEDIAFIFO           ((uint32_t) 0xFFFFFF34UL)
#define CMD_MEMCPY              ((uint32_t) 0xFFFFFF1BUL)
#define CMD_MEMCRC              ((uint32_t) 0xFFFFFF16UL)
#define CMD_MEMSET              ((uint32_t) 0xFFFFFF19UL)
#define CMD_MEMWRITE            ((uint32_t) 0xFFFFFF18UL)
#define CMD_MEMZERO             ((uint32_t) 0xFFFFFF1AUL)
#define CMD_NEWLIST             ((uint32_t) 0xFFFFFF5CUL)
#define CMD_NOP                 ((uint32_t) 0xFFFFFF53UL)
#define CMD_NUMBER              ((uint32_t) 0xFFFFFF2AUL)
#define CMD_PLAYVIDEO           ((uint32_t) 0xFFFFFF35UL)
#define CMD_PLAYWAV             ((uint32_t) 0xFFFFFF79UL)
#define CMD_PROGRESS            ((uint32_t) 0xFFFFFF0DUL)
#define CMD_REGREAD             ((uint32_t) 0xFFFFFF17UL)
#define CMD_REGWRITE            ((uint32_t) 0xFFFFFF86UL)
#define CMD_RENDERTARGET        ((uint32_t) 0xFFFFFF8DUL)
#define CMD_RESETFONTS          ((uint32_t) 0xFFFFFF4CUL)
#define CMD_RESTORECONTEXT      ((uint32_t) 0xFFFFFF7DUL)
#define CMD_RESULT              ((uint32_t) 0xFFFFFF89UL)
#define CMD_RETURN              ((uint32_t) 0xFFFFFF5AUL)
#define CMD_ROMFONT             ((uint32_t) 0xFFFFFF39UL)
#define CMD_ROTATE              ((uint32_t) 0xFFFFFF26UL)
#define CMD_ROTATEAROUND        ((uint32_t) 0xFFFFFF4BUL)
#define CMD_RUNANIM             ((uint32_t) 0xFFFFFF60UL)
#define CMD_SAVECONTEXT         ((uint32_t) 0xFFFFFF7CUL)
#define CMD_SCALE               ((uint32_t) 0xFFFFFF25UL)
#define CMD_SCREENSAVER         ((uint32_t) 0xFFFFFF2BUL)
#define CMD_SCROLLBAR           ((uint32_t) 0xFFFFFF0FUL)
#define CMD_SDATTACH            ((uint32_t) 0xFFFFFF6EUL)
#define CMD_SDBLOCKREAD         ((uint32_t) 0xFFFFFF6FUL)
#define CMD_SETBASE             ((uint32_t) 0xFFFFFF33UL)
#define CMD_SETBITMAP           ((uint32_t) 0xFFFFFF3DUL)
#define CMD_SETFONT             ((uint32_t) 0xFFFFFF36UL)
#define CMD_SETMATRIX           ((uint32_t) 0xFFFFFF27UL)
#define CMD_SETROTATE           ((uint32_t) 0xFFFFFF31UL)
#define CMD_SETSCRATCH          ((uint32_t) 0xFFFFFF37UL)
#define CMD_SKETCH              ((uint32_t) 0xFFFFFF2CUL)
#define CMD_SKIPCOND            ((uint32_t) 0xFFFFFF8CUL)
#define CMD_SLIDER              ((uint32_t) 0xFFFFFF0EUL)
#define CMD_SNAPSHOT            ((uint32_t) 0xFFFFFF1DUL)
#define CMD_SPINNER             ((uint32_t) 0xFFFFFF14UL)
#define CMD_STOP                ((uint32_t) 0xFFFFFF15UL)
#define CMD_SWAP                ((uint32_t) 0xFFFFFF01UL)
#define CMD_SYNC                ((uint32_t) 0xFFFFFF3CUL)
#define CMD_TESTCARD            ((uint32_t) 0xFFFFFF57UL)
#define CMD_TEXT                ((uint32_t) 0xFFFFFF0AUL)
#define CMD_TEXTDIM             ((uint32_t) 0xFFFFFF84UL)
#define CMD_TOGGLE              ((uint32_t) 0xFFFFFF10UL)
#define CMD_TRACK               ((uint32_t) 0xFFFFFF28UL)
#define CMD_TRANSLATE           ((uint32_t) 0xFFFFFF24UL)
#define CMD_VIDEOFRAME          ((uint32_t) 0xFFFFFF3BUL)
#define CMD_VIDEOSTART          ((uint32_t) 0xFFFFFF3AUL)
#define CMD_WAIT                ((uint32_t) 0xFFFFFF59UL)
#define CMD_WAITCHANGE          ((uint32_t) 0xFFFFFF67UL)
#define CMD_WAITCOND            ((uint32_t) 0xFFFFFF78UL)
#define CMD_WATCHDOG            ((uint32_t) 0xFFFFFF83UL)

#else

/* Memory */
#define EVE_RAM_G         ((uint32_t) 0x00000000UL)
#define EVE_ROM_CHIPID    ((uint32_t) 0x000C0000UL)
#define EVE_ROM_FONT      ((uint32_t) 0x001E0000UL)
#define EVE_ROM_FONTROOT  ((uint32_t) 0x002FFFFCUL)
#define EVE_RAM_DL        ((uint32_t) 0x00300000UL)
#define EVE_RAM_REG       ((uint32_t) 0x00302000UL)
#define EVE_RAM_CMD       ((uint32_t) 0x00308000UL)

/* Memory buffer sizes */
#define EVE_RAM_G_SIZE      ((uint32_t) 1024U*1024UL)
#define EVE_CMD_FIFO_SIZE   ((uint32_t) 4U*1024UL)
#define EVE_RAM_DL_SIZE     ((uint32_t) 8U*1024UL)

#define EVE_CMD_FIFO_FULL ((uint16_t) 0xffcU)
#define EVE_CMD_FIFO_HALF ((uint16_t) 0x800U)

/* Inline functions that work like the function-like macros from Bridgetek: */

/**
 * @brief Set the bitmap handle.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t BITMAP_HANDLE(const uint8_t handle)
{
    return (DL_BITMAP_HANDLE | ((handle) & 0x1FUL));
}

#if EVE_GEN < 3 /* only define these for FT81x */
/**
 * @brief Set the A coefficient of the bitmap transform matrix.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t BITMAP_TRANSFORM_A(const uint32_t val)
{
    return (DL_BITMAP_TRANSFORM_A | (val & 0x1FFFFUL));
}

/**
 * @brief Set the B coefficient of the bitmap transform matrix.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t BITMAP_TRANSFORM_B(const uint32_t val)
{
    return (DL_BITMAP_TRANSFORM_B | (val & 0x1FFFFUL));
}

/**
 * @brief Set the D coefficient of the bitmap transform matrix.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t BITMAP_TRANSFORM_D(const uint32_t val)
{
    return (DL_BITMAP_TRANSFORM_D | (val & 0x1FFFFUL));
}

/**
 * @brief Set he E coefficient of the bitmap transform matrix.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t BITMAP_TRANSFORM_E(const uint32_t val)
{
    return (DL_BITMAP_TRANSFORM_E | (val & 0x1FFFFUL));
}
#endif

/**
 * @brief Execute a sequence of commands at another location in the display list.
 * @note valid range for dest is from zero to 2047
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t CALL(const uint16_t dest)
{
    return (DL_CALL | (dest & 0x7FFUL));
}

/**
 * @brief Set clear value for the tag buffer.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t CLEAR_TAG(const uint8_t val)
{
    return (DL_CLEAR_TAG | val);
}

/**
 * @brief Execute commands at another location in the display list.
 * @note valid range for dest is from zero to 2047
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t JUMP(const uint16_t dest)
{
    return (DL_JUMP | (dest & 0x7FFUL));
}

/**
 * @brief Set the base address of the palette.
 * @note 2-byte alignment is required if pixel format is PALETTE4444 or PALETTE565.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t PALETTE_SOURCE(const uint32_t addr)
{
    return (DL_PALETTE_SOURCE | (addr & 0x3FFFFFUL));
}

/**
 * @brief Attach the tag value for the following graphics objects drawn on the screen.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t TAG(const uint8_t tagval)
{
    return (DL_TAG | tagval);
}

/* Bitmap formats */
#define EVE_PALETTED   ((uint8_t) 8UL)
#define EVE_TEXT8X8    ((uint8_t) 9UL)
#define EVE_TEXTVGA    ((uint8_t) 10UL)

/* Host commands */
#define EVE_ACTIVE       ((uint8_t) 0x00U) /* place EVE in active state */
#define EVE_STANDBY      ((uint8_t) 0x41U) /* place EVE in Standby (clk running) */
#define EVE_SLEEP        ((uint8_t) 0x42U) /* place EVE in Sleep (clk off) */
#define EVE_CLKEXT       ((uint8_t) 0x44U) /* select external clock source */
#if EVE_GEN < 4
#define EVE_CLKINT       ((uint8_t) 0x48U) /* select internal clock source, not a valid option for BT817 / BT818 */
#endif
#define EVE_PWRDOWN      ((uint8_t) 0x50U) /* place EVE in Power Down (core off) */
#define EVE_CLKSEL       ((uint8_t) 0x61U) /* configure system clock */
#define EVE_RST_PULSE    ((uint8_t) 0x68U) /* reset core - all registers default and processors reset */
#define EVE_CORERST      ((uint8_t) 0x68U) /* reset core - all registers default and processors reset */
#define EVE_PINDRIVE     ((uint8_t) 0x70U) /* setup drive strength for various pins */
#define EVE_PIN_PD_STATE ((uint8_t) 0x71U) /* setup how pins behave during power down */

/* ADC */
#define EVE_ADC_DIFFERENTIAL     ((uint32_t) 1UL)
#define EVE_ADC_SINGLE_ENDED     ((uint32_t) 0UL)

/* Fonts */
#define EVE_NUMCHAR_PERFONT     ((uint32_t) 128UL)  /* number of font characters per bitmap handle */
#define EVE_FONT_TABLE_SIZE     ((uint32_t) 148UL)  /* size of the font table - utilized for lookup by the graphics engine */
#define EVE_FONT_TABLE_POINTER  ((uint32_t) 0xFFFFCUL) /* pointer to the inbuilt font tables starting from bitmap handle 16 */

/* Audio sample type defines */
#define EVE_LINEAR_SAMPLES       ((uint32_t) 0UL) /* 8bit signed samples */
#define EVE_ULAW_SAMPLES         ((uint32_t) 1UL) /* 8bit ulaw samples */
#define EVE_ADPCM_SAMPLES        ((uint32_t) 2UL) /* 4bit ima adpcm samples */

/* Synthesized sound */
#define EVE_SILENCE      ((uint8_t) 0x00U)
#define EVE_SQUAREWAVE   ((uint8_t) 0x01U)
#define EVE_SINEWAVE     ((uint8_t) 0x02U)
#define EVE_SAWTOOTH     ((uint8_t) 0x03U)
#define EVE_TRIANGLE     ((uint8_t) 0x04U)
#define EVE_BEEPING      ((uint8_t) 0x05U)
#define EVE_ALARM        ((uint8_t) 0x06U)
#define EVE_WARBLE       ((uint8_t) 0x07U)
#define EVE_CAROUSEL     ((uint8_t) 0x08U)
#define EVE_HARP         ((uint8_t) 0x40U)
#define EVE_XYLOPHONE    ((uint8_t) 0x41U)
#define EVE_TUBA         ((uint8_t) 0x42U)
#define EVE_GLOCKENSPIEL ((uint8_t) 0x43U)
#define EVE_ORGAN        ((uint8_t) 0x44U)
#define EVE_TRUMPET      ((uint8_t) 0x45U)
#define EVE_PIANO        ((uint8_t) 0x46U)
#define EVE_CHIMES       ((uint8_t) 0x47U)
#define EVE_MUSICBOX     ((uint8_t) 0x48U)
#define EVE_BELL         ((uint8_t) 0x49U)
#define EVE_CLICK        ((uint8_t) 0x50U)
#define EVE_SWITCH       ((uint8_t) 0x51U)
#define EVE_COWBELL      ((uint8_t) 0x52U)
#define EVE_NOTCH        ((uint8_t) 0x53U)
#define EVE_HIHAT        ((uint8_t) 0x54U)
#define EVE_KICKDRUM     ((uint8_t) 0x55U)
#define EVE_POP          ((uint8_t) 0x56U)
#define EVE_CLACK        ((uint8_t) 0x57U)
#define EVE_CHACK        ((uint8_t) 0x58U)
#define EVE_MUTE         ((uint8_t) 0x60U)
#define EVE_UNMUTE       ((uint8_t) 0x61U)

//#define EVE_PIPS(n)      ((uint8_t) (0x0FU + (n)))
/**
 * @brief Returns a sound-effect value for short pip(s)
 * @return an 8 bit value to be placed in REG_SOUND
 * @note valid values for num are 1...16
 */
static inline uint8_t EVE_PIPS(const uint8_t num)
{
    return (num + 0x0FU);
}

/* Synthesized sound frequencies, midi note */
#define EVE_MIDI_A0   ((uint8_t) 21U)
#define EVE_MIDI_A_0  ((uint8_t) 22U)
#define EVE_MIDI_B0   ((uint8_t) 23U)
#define EVE_MIDI_C1   ((uint8_t) 24U)
#define EVE_MIDI_C_1  ((uint8_t) 25U)
#define EVE_MIDI_D1   ((uint8_t) 26U)
#define EVE_MIDI_D_1  ((uint8_t) 27U)
#define EVE_MIDI_E1   ((uint8_t) 28U)
#define EVE_MIDI_F1   ((uint8_t) 29U)
#define EVE_MIDI_F_1  ((uint8_t) 30U)
#define EVE_MIDI_G1   ((uint8_t) 31U)
#define EVE_MIDI_G_1  ((uint8_t) 32U)
#define EVE_MIDI_A1   ((uint8_t) 33U)
#define EVE_MIDI_A_1  ((uint8_t) 34U)
#define EVE_MIDI_B1   ((uint8_t) 35U)
#define EVE_MIDI_C2   ((uint8_t) 36U)
#define EVE_MIDI_C_2  ((uint8_t) 37U)
#define EVE_MIDI_D2   ((uint8_t) 38U)
#define EVE_MIDI_D_2  ((uint8_t) 39U)
#define EVE_MIDI_E2   ((uint8_t) 40U)
#define EVE_MIDI_F2   ((uint8_t) 41U)
#define EVE_MIDI_F_2  ((uint8_t) 42U)
#define EVE_MIDI_G2   ((uint8_t) 43U)
#define EVE_MIDI_G_2  ((uint8_t) 44U)
#define EVE_MIDI_A2   ((uint8_t) 45U)
#define EVE_MIDI_A_2  ((uint8_t) 46U)
#define EVE_MIDI_B2   ((uint8_t) 47U)
#define EVE_MIDI_C3   ((uint8_t) 48U)
#define EVE_MIDI_C_3  ((uint8_t) 49U)
#define EVE_MIDI_D3   ((uint8_t) 50U)
#define EVE_MIDI_D_3  ((uint8_t) 51U)
#define EVE_MIDI_E3   ((uint8_t) 52U)
#define EVE_MIDI_F3   ((uint8_t) 53U)
#define EVE_MIDI_F_3  ((uint8_t) 54U)
#define EVE_MIDI_G3   ((uint8_t) 55U)
#define EVE_MIDI_G_3  ((uint8_t) 56U)
#define EVE_MIDI_A3   ((uint8_t) 57U)
#define EVE_MIDI_A_3  ((uint8_t) 58U)
#define EVE_MIDI_B3   ((uint8_t) 59U)
#define EVE_MIDI_C4   ((uint8_t) 60U)
#define EVE_MIDI_C_4  ((uint8_t) 61U)
#define EVE_MIDI_D4   ((uint8_t) 62U)
#define EVE_MIDI_D_4  ((uint8_t) 63U)
#define EVE_MIDI_E4   ((uint8_t) 64U)
#define EVE_MIDI_F4   ((uint8_t) 65U)
#define EVE_MIDI_F_4  ((uint8_t) 66U)
#define EVE_MIDI_G4   ((uint8_t) 67U)
#define EVE_MIDI_G_4  ((uint8_t) 68U)
#define EVE_MIDI_A4   ((uint8_t) 69U)
#define EVE_MIDI_A_4  ((uint8_t) 70U)
#define EVE_MIDI_B4   ((uint8_t) 71U)
#define EVE_MIDI_C5   ((uint8_t) 72U)
#define EVE_MIDI_C_5  ((uint8_t) 73U)
#define EVE_MIDI_D5   ((uint8_t) 74U)
#define EVE_MIDI_D_5  ((uint8_t) 75U)
#define EVE_MIDI_E5   ((uint8_t) 76U)
#define EVE_MIDI_F5   ((uint8_t) 77U)
#define EVE_MIDI_F_5  ((uint8_t) 78U)
#define EVE_MIDI_G5   ((uint8_t) 79U)
#define EVE_MIDI_G_5  ((uint8_t) 80U)
#define EVE_MIDI_A5   ((uint8_t) 81U)
#define EVE_MIDI_A_5  ((uint8_t) 82U)
#define EVE_MIDI_B5   ((uint8_t) 83U)
#define EVE_MIDI_C6   ((uint8_t) 84U)
#define EVE_MIDI_C_6  ((uint8_t) 85U)
#define EVE_MIDI_D6   ((uint8_t) 86U)
#define EVE_MIDI_D_6  ((uint8_t) 87U)
#define EVE_MIDI_E6   ((uint8_t) 88U)
#define EVE_MIDI_F6   ((uint8_t) 89U)
#define EVE_MIDI_F_6  ((uint8_t) 90U)
#define EVE_MIDI_G6   ((uint8_t) 91U)
#define EVE_MIDI_G_6  ((uint8_t) 92U)
#define EVE_MIDI_A6   ((uint8_t) 93U)
#define EVE_MIDI_A_6  ((uint8_t) 94U)
#define EVE_MIDI_B6   ((uint8_t) 95U)
#define EVE_MIDI_C7   ((uint8_t) 96U)
#define EVE_MIDI_C_7  ((uint8_t) 97U)
#define EVE_MIDI_D7   ((uint8_t) 98U)
#define EVE_MIDI_D_7  ((uint8_t) 99U)
#define EVE_MIDI_E7   ((uint8_t) 100U)
#define EVE_MIDI_F7   ((uint8_t) 101U)
#define EVE_MIDI_F_7  ((uint8_t) 102U)
#define EVE_MIDI_G7   ((uint8_t) 103U)
#define EVE_MIDI_G_7  ((uint8_t) 104U)
#define EVE_MIDI_A7   ((uint8_t) 105U)
#define EVE_MIDI_A_7  ((uint8_t) 106U)
#define EVE_MIDI_B7   ((uint8_t) 107U)
#define EVE_MIDI_C8   ((uint8_t) 108U)

/* GPIO bits */
#define EVE_GPIO0  ((uint8_t) 0U)
#define EVE_GPIO1  ((uint8_t) 1U) /* default gpio pin for audio shutdown, 1 - enable, 0 - disable */
#define EVE_GPIO7  ((uint8_t) 7U) /* default gpio pin for display enable, 1 - enable, 0 - disable */

/* Display rotation */
#define EVE_DISPLAY_0   ((uint8_t) 0U) /* 0 degrees rotation */
#define EVE_DISPLAY_180 ((uint8_t) 1U) /* 180 degrees rotation */

/* Commands */
#define CMD_APPEND       ((uint32_t) 0xFFFFFF1EUL)
#define CMD_BGCOLOR      ((uint32_t) 0xFFFFFF09UL)
#define CMD_BUTTON       ((uint32_t) 0xFFFFFF0DUL)
#define CMD_CALIBRATE    ((uint32_t) 0xFFFFFF15UL)
#define CMD_CLOCK        ((uint32_t) 0xFFFFFF14UL)
#define CMD_COLDSTART    ((uint32_t) 0xFFFFFF32UL)
#define CMD_DIAL         ((uint32_t) 0xFFFFFF2DUL)
#define CMD_DLSTART      ((uint32_t) 0xFFFFFF00UL)
#define CMD_FGCOLOR      ((uint32_t) 0xFFFFFF0AUL)
#define CMD_GAUGE        ((uint32_t) 0xFFFFFF13UL)
#define CMD_GETMATRIX    ((uint32_t) 0xFFFFFF33UL)
#define CMD_GETPROPS     ((uint32_t) 0xFFFFFF25UL)
#define CMD_GETPTR       ((uint32_t) 0xFFFFFF23UL)
#define CMD_GRADCOLOR    ((uint32_t) 0xFFFFFF34UL)
#define CMD_GRADIENT     ((uint32_t) 0xFFFFFF0BUL)
#define CMD_INFLATE      ((uint32_t) 0xFFFFFF22UL)
#define CMD_INTERRUPT    ((uint32_t) 0xFFFFFF02UL)
#define CMD_KEYS         ((uint32_t) 0xFFFFFF0EUL)
#define CMD_LOADIDENTITY ((uint32_t) 0xFFFFFF26UL)
#define CMD_LOADIMAGE    ((uint32_t) 0xFFFFFF24UL)
#define CMD_LOGO         ((uint32_t) 0xFFFFFF31UL)
#define CMD_MEDIAFIFO    ((uint32_t) 0xFFFFFF39UL)
#define CMD_MEMCPY       ((uint32_t) 0xFFFFFF1DUL)
#define CMD_MEMCRC       ((uint32_t) 0xFFFFFF18UL)
#define CMD_MEMSET       ((uint32_t) 0xFFFFFF1BUL)
#define CMD_MEMWRITE     ((uint32_t) 0xFFFFFF1AUL)
#define CMD_MEMZERO      ((uint32_t) 0xFFFFFF1CUL)
#define CMD_NUMBER       ((uint32_t) 0xFFFFFF2EUL)
#define CMD_PLAYVIDEO    ((uint32_t) 0xFFFFFF3AUL)
#define CMD_PROGRESS     ((uint32_t) 0xFFFFFF0FUL)
#define CMD_REGREAD      ((uint32_t) 0xFFFFFF19UL)
#define CMD_ROMFONT      ((uint32_t) 0xFFFFFF3FUL)
#define CMD_ROTATE       ((uint32_t) 0xFFFFFF29UL)
#define CMD_SCALE        ((uint32_t) 0xFFFFFF28UL)
#define CMD_SCREENSAVER  ((uint32_t) 0xFFFFFF2FUL)
#define CMD_SCROLLBAR    ((uint32_t) 0xFFFFFF11UL)
#define CMD_SETBASE      ((uint32_t) 0xFFFFFF38UL)
#define CMD_SETBITMAP    ((uint32_t) 0xFFFFFF43UL)
#define CMD_SETFONT      ((uint32_t) 0xFFFFFF2BUL)
#define CMD_SETFONT2     ((uint32_t) 0xFFFFFF3BUL)
#define CMD_SETMATRIX    ((uint32_t) 0xFFFFFF2AUL)
#define CMD_SETROTATE    ((uint32_t) 0xFFFFFF36UL)
#define CMD_SETSCRATCH   ((uint32_t) 0xFFFFFF3CUL)
#define CMD_SKETCH       ((uint32_t) 0xFFFFFF30UL)
#define CMD_SLIDER       ((uint32_t) 0xFFFFFF10UL)
#define CMD_SNAPSHOT     ((uint32_t) 0xFFFFFF1FUL)
#define CMD_SNAPSHOT2    ((uint32_t) 0xFFFFFF37UL)
#define CMD_SPINNER      ((uint32_t) 0xFFFFFF16UL)
#define CMD_STOP         ((uint32_t) 0xFFFFFF17UL)
#define CMD_SWAP         ((uint32_t) 0xFFFFFF01UL)
#define CMD_SYNC         ((uint32_t) 0xFFFFFF42UL)
#define CMD_TEXT         ((uint32_t) 0xFFFFFF0CUL)
#define CMD_TOGGLE       ((uint32_t) 0xFFFFFF12UL)
#define CMD_TRACK        ((uint32_t) 0xFFFFFF2CUL)
#define CMD_TRANSLATE    ((uint32_t) 0xFFFFFF27UL)
#define CMD_VIDEOFRAME   ((uint32_t) 0xFFFFFF41UL)
#define CMD_VIDEOSTART   ((uint32_t) 0xFFFFFF40UL)

/* Registers */
#define REG_ANA_COMP         ((uint32_t) 0x00302184UL) /* only listed in datasheet */
#define REG_BIST_EN          ((uint32_t) 0x00302174UL) /* only listed in datasheet */
#define REG_CLOCK            ((uint32_t) 0x00302008UL)
#define REG_CMDB_SPACE       ((uint32_t) 0x00302574UL)
#define REG_CMDB_WRITE       ((uint32_t) 0x00302578UL)
#define REG_CMD_DL           ((uint32_t) 0x00302100UL)
#define REG_CMD_READ         ((uint32_t) 0x003020f8UL)
#define REG_CMD_WRITE        ((uint32_t) 0x003020fcUL)
#define REG_CPURESET         ((uint32_t) 0x00302020UL)
#define REG_CSPREAD          ((uint32_t) 0x00302068UL)
#define REG_CTOUCH_EXTENDED  ((uint32_t) 0x00302108UL)
#define REG_CTOUCH_TOUCH0_XY ((uint32_t) 0x00302124UL) /* only listed in datasheet */
#define REG_CTOUCH_TOUCH4_X  ((uint32_t) 0x0030216cUL)
#define REG_CTOUCH_TOUCH4_Y  ((uint32_t) 0x00302120UL)
#define REG_CTOUCH_TOUCH1_XY ((uint32_t) 0x0030211cUL)
#define REG_CTOUCH_TOUCH2_XY ((uint32_t) 0x0030218cUL)
#define REG_CTOUCH_TOUCH3_XY ((uint32_t) 0x00302190UL)
#define REG_TOUCH_CONFIG     ((uint32_t) 0x00302168UL)
#define REG_DATESTAMP        ((uint32_t) 0x00302564UL) /* only listed in datasheet */
#define REG_DITHER           ((uint32_t) 0x00302060UL)
#define REG_DLSWAP           ((uint32_t) 0x00302054UL)
#define REG_FRAMES           ((uint32_t) 0x00302004UL)
#define REG_FREQUENCY        ((uint32_t) 0x0030200cUL)
#define REG_GPIO             ((uint32_t) 0x00302094UL)
#define REG_GPIOX            ((uint32_t) 0x0030209cUL)
#define REG_GPIOX_DIR        ((uint32_t) 0x00302098UL)
#define REG_GPIO_DIR         ((uint32_t) 0x00302090UL)
#define REG_HCYCLE           ((uint32_t) 0x0030202cUL)
#define REG_HOFFSET          ((uint32_t) 0x00302030UL)
#define REG_HSIZE            ((uint32_t) 0x00302034UL)
#define REG_HSYNC0           ((uint32_t) 0x00302038UL)
#define REG_HSYNC1           ((uint32_t) 0x0030203cUL)
#define REG_ID               ((uint32_t) 0x00302000UL)
#define REG_INT_EN           ((uint32_t) 0x003020acUL)
#define REG_INT_FLAGS        ((uint32_t) 0x003020a8UL)
#define REG_INT_MASK         ((uint32_t) 0x003020b0UL)
#define REG_MACRO_0          ((uint32_t) 0x003020d8UL)
#define REG_MACRO_1          ((uint32_t) 0x003020dcUL)
#define REG_MEDIAFIFO_READ   ((uint32_t) 0x00309014UL) /* only listed in programmers guide */
#define REG_MEDIAFIFO_WRITE  ((uint32_t) 0x00309018UL) /* only listed in programmers guide */
#define REG_OUTBITS          ((uint32_t) 0x0030205cUL)
#define REG_PCLK             ((uint32_t) 0x00302070UL)
#define REG_PCLK_POL         ((uint32_t) 0x0030206cUL)
#define REG_PLAY             ((uint32_t) 0x0030208cUL)
#define REG_PLAYBACK_FORMAT  ((uint32_t) 0x003020c4UL)
#define REG_PLAYBACK_FREQ    ((uint32_t) 0x003020c0UL)
#define REG_PLAYBACK_LENGTH  ((uint32_t) 0x003020b8UL)
#define REG_PLAYBACK_LOOP    ((uint32_t) 0x003020c8UL)
#define REG_PLAYBACK_PLAY    ((uint32_t) 0x003020ccUL)
#define REG_PLAYBACK_READPTR ((uint32_t) 0x003020bcUL)
#define REG_PLAYBACK_START   ((uint32_t) 0x003020b4UL)
#define REG_PWM_DUTY         ((uint32_t) 0x003020d4UL)
#define REG_PWM_HZ           ((uint32_t) 0x003020d0UL)
#define REG_RENDERMODE       ((uint32_t) 0x00302010UL) /* only listed in datasheet */
#define REG_ROTATE           ((uint32_t) 0x00302058UL)
#define REG_SNAPFORMAT       ((uint32_t) 0x0030201cUL) /* only listed in datasheet */
#define REG_SNAPSHOT         ((uint32_t) 0x00302018UL) /* only listed in datasheet */
#define REG_SNAPY            ((uint32_t) 0x00302014UL) /* only listed in datasheet */
#define REG_SOUND            ((uint32_t) 0x00302088UL)
#define REG_SPI_WIDTH        ((uint32_t) 0x00302188UL) /* listed with false offset in programmers guide V1.1 */
#define REG_SWIZZLE          ((uint32_t) 0x00302064UL)
#define REG_TAG              ((uint32_t) 0x0030207cUL)
#define REG_TAG_X            ((uint32_t) 0x00302074UL)
#define REG_TAG_Y            ((uint32_t) 0x00302078UL)
#define REG_TAP_CRC          ((uint32_t) 0x00302024UL) /* only listed in datasheet */
#define REG_TAP_MASK         ((uint32_t) 0x00302028UL) /* only listed in datasheet */
#define REG_TOUCH_ADC_MODE   ((uint32_t) 0x00302108UL)
#define REG_TOUCH_CHARGE     ((uint32_t) 0x0030210cUL)
#define REG_TOUCH_DIRECT_XY  ((uint32_t) 0x0030218cUL)
#define REG_TOUCH_DIRECT_Z1Z2 ((uint32_t) 0x00302190UL)
#define REG_TOUCH_MODE       ((uint32_t) 0x00302104UL)
#define REG_TOUCH_OVERSAMPLE ((uint32_t) 0x00302114UL)
#define REG_TOUCH_RAW_XY     ((uint32_t) 0x0030211cUL)
#define REG_TOUCH_RZ         ((uint32_t) 0x00302120UL)
#define REG_TOUCH_RZTHRESH   ((uint32_t) 0x00302118UL)
#define REG_TOUCH_SCREEN_XY  ((uint32_t) 0x00302124UL)
#define REG_TOUCH_SETTLE     ((uint32_t) 0x00302110UL)
#define REG_TOUCH_TAG        ((uint32_t) 0x0030212cUL)
#define REG_TOUCH_TAG1       ((uint32_t) 0x00302134UL) /* only listed in datasheet */
#define REG_TOUCH_TAG1_XY    ((uint32_t) 0x00302130UL) /* only listed in datasheet */
#define REG_TOUCH_TAG2       ((uint32_t) 0x0030213cUL) /* only listed in datasheet */
#define REG_TOUCH_TAG2_XY    ((uint32_t) 0x00302138UL) /* only listed in datasheet */
#define REG_TOUCH_TAG3       ((uint32_t) 0x00302144UL) /* only listed in datasheet */
#define REG_TOUCH_TAG3_XY    ((uint32_t) 0x00302140UL) /* only listed in datasheet */
#define REG_TOUCH_TAG4       ((uint32_t) 0x0030214cUL)/* only listed in datasheet */
#define REG_TOUCH_TAG4_XY    ((uint32_t) 0x00302148UL) /* only listed in datasheet */
#define REG_TOUCH_TAG_XY     ((uint32_t) 0x00302128UL)
#define REG_TOUCH_TRANSFORM_A ((uint32_t) 0x00302150UL)
#define REG_TOUCH_TRANSFORM_B ((uint32_t) 0x00302154UL)
#define REG_TOUCH_TRANSFORM_C ((uint32_t) 0x00302158UL)
#define REG_TOUCH_TRANSFORM_D ((uint32_t) 0x0030215cUL)
#define REG_TOUCH_TRANSFORM_E ((uint32_t) 0x00302160UL)
#define REG_TOUCH_TRANSFORM_F ((uint32_t) 0x00302164UL)
#define REG_TRACKER          ((uint32_t) 0x00309000UL) /* only listed in programmers guide */
#define REG_TRACKER_1        ((uint32_t) 0x00309004UL) /* only listed in programmers guide */
#define REG_TRACKER_2        ((uint32_t) 0x00309008UL) /* only listed in programmers guide */
#define REG_TRACKER_3        ((uint32_t) 0x0030900cUL) /* only listed in programmers guide */
#define REG_TRACKER_4        ((uint32_t) 0x00309010UL) /* only listed in programmers guide */
#define REG_TRIM             ((uint32_t) 0x00302180UL)
#define REG_VCYCLE           ((uint32_t) 0x00302040UL)
#define REG_VOFFSET          ((uint32_t) 0x00302044UL)
#define REG_VOL_PB           ((uint32_t) 0x00302080UL)
#define REG_VOL_SOUND        ((uint32_t) 0x00302084UL)
#define REG_VSIZE            ((uint32_t) 0x00302048UL)
#define REG_VSYNC0           ((uint32_t) 0x0030204cUL)
#define REG_VSYNC1           ((uint32_t) 0x00302050UL)

/* ########## EVE Generation 3: BT815 / BT816 definitions ########## */

#if EVE_GEN > 2

#define EVE_GLFORMAT  ((uint32_t) 31UL) /* used with BITMAP_LAYOUT to indicate bitmap-format is specified by BITMAP_EXT_FORMAT */

#define DL_BITMAP_EXT_FORMAT ((uint32_t) 0x2E000000UL) /* requires OR'd arguments */
#define DL_BITMAP_SWIZZLE    ((uint32_t) 0x2F000000UL)
/* #define DL_INT_FRR           ((uint32_t) 0x30000000UL) */ /* ESE displays "Internal: flash read result" - undocumented display list command */

/* Extended Bitmap formats */
#define EVE_ASTC_4X4   ((uint32_t) 37808UL)
#define EVE_ASTC_5X4   ((uint32_t) 37809UL)
#define EVE_ASTC_5X5   ((uint32_t) 37810UL)
#define EVE_ASTC_6X5   ((uint32_t) 37811UL)
#define EVE_ASTC_6X6   ((uint32_t) 37812UL)
#define EVE_ASTC_8X5   ((uint32_t) 37813UL)
#define EVE_ASTC_8X6   ((uint32_t) 37814UL)
#define EVE_ASTC_8X8   ((uint32_t) 37815UL)
#define EVE_ASTC_10X5  ((uint32_t) 37816UL)
#define EVE_ASTC_10X6  ((uint32_t) 37817UL)
#define EVE_ASTC_10X8  ((uint32_t) 37818UL)
#define EVE_ASTC_10X10 ((uint32_t) 37819UL)
#define EVE_ASTC_12X10 ((uint32_t) 37820UL)
#define EVE_ASTC_12X12 ((uint32_t) 37821UL)

#define EVE_RAM_ERR_REPORT      ((uint32_t) 0x309800UL) /* max 128 bytes null terminated string */
#define EVE_RAM_FLASH           ((uint32_t) 0x800000UL)
#define EVE_RAM_FLASH_POSTBLOB  ((uint32_t) 0x801000UL)

#define EVE_OPT_FLASH  ((uint16_t) 64U)
#define EVE_OPT_OVERLAY ((uint16_t) 128U)
#define EVE_OPT_FORMAT ((uint16_t) 4096U)
#define EVE_OPT_FILL   ((uint16_t) 8192U)

/* Commands for BT815 / BT816 */
#define CMD_BITMAP_TRANSFORM ((uint32_t) 0xFFFFFF21UL)
#define CMD_FLASHERASE       ((uint32_t) 0xFFFFFF44UL) /* does not need a dedicated function, just use EVE_cmd_dl(CMD_FLASHERASE) */
#define CMD_FLASHWRITE       ((uint32_t) 0xFFFFFF45UL)
#define CMD_FLASHREAD        ((uint32_t) 0xFFFFFF46UL)
#define CMD_FLASHUPDATE      ((uint32_t) 0xFFFFFF47UL)
#define CMD_FLASHDETACH      ((uint32_t) 0xFFFFFF48UL) /* does not need a dedicated function, just use EVE_cmd_dl(CMD_FLASHDETACH) */
#define CMD_FLASHATTACH      ((uint32_t) 0xFFFFFF49UL) /* does not need a dedicated function, just use EVE_cmd_dl(CMD_FLASHATTACH) */
#define CMD_FLASHFAST        ((uint32_t) 0xFFFFFF4AUL)
#define CMD_FLASHSPIDESEL    ((uint32_t) 0xFFFFFF4BUL) /* does not need a dedicated function, just use EVE_cmd_dl(CMD_FLASHSPIDESEL) */
#define CMD_FLASHSPITX       ((uint32_t) 0xFFFFFF4CUL)
#define CMD_FLASHSPIRX       ((uint32_t) 0xFFFFFF4DUL)
#define CMD_FLASHSOURCE      ((uint32_t) 0xFFFFFF4EUL)
#define CMD_CLEARCACHE       ((uint32_t) 0xFFFFFF4FUL) /* does not need a dedicated function, just use EVE_cmd_dl(CMD_CLEARCACHE) */
#define CMD_INFLATE2         ((uint32_t) 0xFFFFFF50UL)
#define CMD_ROTATEAROUND     ((uint32_t) 0xFFFFFF51UL)
#define CMD_RESETFONTS       ((uint32_t) 0xFFFFFF52UL) /* does not need a dedicated function, just use EVE_cmd_dl(CMD_RESETFONTS) */
#define CMD_ANIMSTART        ((uint32_t) 0xFFFFFF53UL)
#define CMD_ANIMSTOP         ((uint32_t) 0xFFFFFF54UL)
#define CMD_ANIMXY           ((uint32_t) 0xFFFFFF55UL)
#define CMD_ANIMDRAW         ((uint32_t) 0xFFFFFF56UL)
#define CMD_GRADIENTA        ((uint32_t) 0xFFFFFF57UL)
#define CMD_FILLWIDTH        ((uint32_t) 0xFFFFFF58UL)
#define CMD_APPENDF          ((uint32_t) 0xFFFFFF59UL)
#define CMD_ANIMFRAME        ((uint32_t) 0xFFFFFF5AUL)
#define CMD_VIDEOSTARTF      ((uint32_t) 0xFFFFFF5FUL) /* does not need a dedicated function, just use EVE_cmd_dl(CMD_VIDEOSTARTF) */

/* Registers for BT815 / BT816 */
#define REG_ADAPTIVE_FRAMERATE ((uint32_t) 0x0030257cUL)
#define REG_PLAYBACK_PAUSE     ((uint32_t) 0x003025ecUL)
#define REG_FLASH_STATUS       ((uint32_t) 0x003025f0UL)
#define REG_FLASH_SIZE         ((uint32_t) 0x00309024UL)
#define REG_PLAY_CONTROL       ((uint32_t) 0x0030914eUL)
#define REG_COPRO_PATCH_PTR    ((uint32_t) 0x00309162UL)

/* Macros for BT815 / BT816 */

/**
 * @brief Set the extended format of the bitmap.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t BITMAP_EXT_FORMAT(const uint16_t format)
{
    return (DL_BITMAP_EXT_FORMAT | format);
}

/**
 * @brief Set the source for the red, green, blue and alpha channels of a bitmap.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t BITMAP_SWIZZLE(const uint8_t red, const uint8_t green, const uint8_t blue, const uint8_t alpha)
{
    uint32_t const redv = ((red & 7UL) << 9U);
    uint32_t const greenv = ((green & 7UL) << 6U);
    uint32_t const bluev = ((blue & 7UL) << 3U);
    uint32_t const alphav = (alpha & 7UL);
    return (DL_BITMAP_SWIZZLE | redv | greenv | bluev | alphav);
}

/**
 * @brief Set the A coefficient of the bitmap transform matrix.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t BITMAP_TRANSFORM_A(const uint8_t prc, const uint32_t val)
{
    uint32_t const prcv = ((prc & 1UL) << 17U);
    uint32_t const valv = (val & 0x1FFFFUL);
    return (DL_BITMAP_TRANSFORM_A | prcv | valv);
}

/**
 * @brief Set the B coefficient of the bitmap transform matrix.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t BITMAP_TRANSFORM_B(const uint8_t prc, const uint32_t val)
{
    uint32_t const prcv = ((prc & 1UL) << 17U);
    uint32_t const valv = (val & 0x1FFFFUL);
    return (DL_BITMAP_TRANSFORM_B | prcv | valv);
}

/**
 * @brief Set the D coefficient of the bitmap transform matrix.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t BITMAP_TRANSFORM_D(const uint8_t prc, const uint32_t val)
{
    uint32_t const prcv = ((prc & 1UL) << 17U);
    uint32_t const valv = (val & 0x1FFFFUL);
    return (DL_BITMAP_TRANSFORM_D | prcv | valv);
}

/**
 * @brief Set the E coefficient of the bitmap transform matrix.
 * @return a 32 bit word for use with EVE_cmd_dl()
 */
static inline uint32_t BITMAP_TRANSFORM_E(const uint8_t prc, const uint32_t val)
{
    uint32_t const prcv = ((prc & 1UL) << 17U);
    uint32_t const valv = (val & 0x1FFFFUL);
    return (DL_BITMAP_TRANSFORM_E | prcv | valv);
}

#endif  /* EVE_GEN > 2 */

/* ########## EVE Generation 4: BT817 / BT818 definitions ########## */

#if EVE_GEN > 3

/* Commands for BT817 / BT818 */
#define CMD_ANIMFRAMERAM   ((uint32_t) 0xFFFFFF6DUL)
#define CMD_ANIMSTARTRAM   ((uint32_t) 0xFFFFFF6EUL)
#define CMD_APILEVEL       ((uint32_t) 0xFFFFFF63UL)
#define CMD_CALIBRATESUB   ((uint32_t) 0xFFFFFF60UL)
#define CMD_CALLLIST       ((uint32_t) 0xFFFFFF67UL)
#define CMD_ENDLIST        ((uint32_t) 0xFFFFFF69UL) /* does not need a dedicated function, just use EVE_cmd_dl(CMD_ENDLIST) */
#define CMD_FLASHPROGRAM   ((uint32_t) 0xFFFFFF70UL)
#define CMD_FONTCACHE      ((uint32_t) 0xFFFFFF6BUL)
#define CMD_FONTCACHEQUERY ((uint32_t) 0xFFFFFF6CUL)
#define CMD_GETIMAGE       ((uint32_t) 0xFFFFFF64UL)
#define CMD_HSF            ((uint32_t) 0xFFFFFF62UL)
#define CMD_LINETIME       ((uint32_t) 0xFFFFFF5EUL)
#define CMD_NEWLIST        ((uint32_t) 0xFFFFFF68UL)
#define CMD_PCLKFREQ       ((uint32_t) 0xFFFFFF6AUL)
#define CMD_RETURN         ((uint32_t) 0xFFFFFF66UL) /* does not need a dedicated function, just use EVE_cmd_dl(CMD_RETURN) */
#define CMD_RUNANIM        ((uint32_t) 0xFFFFFF6FUL)
#define CMD_TESTCARD       ((uint32_t) 0xFFFFFF61UL) /* does not need a dedicated function, just use EVE_cmd_dl(CMD_TESTCARD) */
#define CMD_WAIT           ((uint32_t) 0xFFFFFF65UL)

/* Registers for BT817 / BT818 */
#define REG_UNDERRUN      ((uint32_t) 0x0030260cUL)
#define REG_AH_HCYCLE_MAX ((uint32_t) 0x00302610UL)
#define REG_PCLK_FREQ     ((uint32_t) 0x00302614UL)
#define REG_PCLK_2X       ((uint32_t) 0x00302618UL)
#define REG_ANIM_ACTIVE   ((uint32_t) 0x0030902CUL)

#endif /*  EVE_GEN > 3 */
#endif /* EVE_GEN < 5 */

#ifdef __cplusplus
}
#endif

#endif /* EVE_H */
